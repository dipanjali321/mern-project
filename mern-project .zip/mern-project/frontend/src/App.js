import React from 'react';
import Dashboard from './pages/Dashboard';  // Import the Dashboard page
import './styles/index.css';  // Import global styles

function App() {
    return (
        <div className="App">
            <Dashboard />  {/* Render the Dashboard component */}
        </div>
    );
}

export default App;
