import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api'; // Base URL for the backend API

/**
 * Axios instance with default configuration.
 */
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    timeout: 10000, // Timeout after 10 seconds
    headers: {
        'Content-Type': 'application/json',
    },
});

/**
 * Fetch transactions with optional pagination and search query.
 * @param {number} page - Page number for pagination.
 * @param {string} search - Search term for filtering transactions.
 * @returns {Promise<Object>} Response data containing transactions, pagination info, etc.
 */
export const fetchTransactions = async (page = 1, search = '') => {
    try {
        const response = await apiClient.get('/transactions', {
            params: { page, search },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching transactions:', error);
        return { data: [], totalPages: 0, currentPage: 1 };
    }
};

/**
 * Fetch statistics data for a specific month.
 * @param {string} month - Month for which statistics are required.
 * @returns {Promise<Object>} Statistics data for the selected month.
 */
export const fetchStatistics = async (month) => {
    try {
        const response = await apiClient.get('/statistics', {
            params: { month },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching statistics:', error);
        return { totalSales: 0, totalRevenue: 0, totalTransactions: 0 };
    }
};

/**
 * Fetch bar chart data for a specific month.
 * @param {string} month - Month for which bar chart data is required.
 * @returns {Promise<Object>} Data for bar chart visualization.
 */
export const fetchBarChartData = async (month) => {
    try {
        const response = await apiClient.get('/bar-chart', {
            params: { month },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching bar chart data:', error);
        return [];
    }
};

/**
 * Fetch pie chart data for a specific month.
 * @param {string} month - Month for which pie chart data is required.
 * @returns {Promise<Object>} Data for pie chart visualization.
 */
export const fetchPieChartData = async (month) => {
    try {
        const response = await apiClient.get('/pie-chart', {
            params: { month },
        });
        return response.data;
    } catch (error) {
        console.error('Error fetching pie chart data:', error);
        return [];
    }
};
