import React, { useState, useEffect } from 'react';
import './StatisticsBox.css';
import { fetchStatistics } from '../../services/api';

const StatisticsBox = ({ selectedMonth }) => {
    const [statistics, setStatistics] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const getStatistics = async () => {
            try {
                setLoading(true);
                const data = await fetchStatistics(selectedMonth);
                setStatistics(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        if (selectedMonth) {
            getStatistics();
        }
    }, [selectedMonth]);

    if (loading) {
        return <div className="statistics-box">Loading...</div>;
    }

    if (error) {
        return <div className="statistics-box error">Error: {error}</div>;
    }

    if (!statistics) {
        return <div className="statistics-box">No data available for {selectedMonth}</div>;
    }

    return (
        <div className="statistics-box">
            <h3>Statistics for {selectedMonth}</h3>
            <p><strong>Total Amount:</strong> ${statistics.totalAmount?.toFixed(2)}</p>
            <p><strong>Average Amount:</strong> ${statistics.averageAmount?.toFixed(2) || 'N/A'}</p>
            <p><strong>Count:</strong> {statistics.count}</p>
        </div>
    );
};

export default StatisticsBox;
