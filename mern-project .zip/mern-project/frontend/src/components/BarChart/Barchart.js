import React, { useEffect, useState } from 'react';
import './BarChart.css';
import { fetchBarChartData } from '../../services/api';

const BarChart = ({ month }) => {
    const [chartData, setChartData] = useState({});

    useEffect(() => {
        const loadChartData = async () => {
            const data = await fetchBarChartData(month);
            setChartData(data);
        };
        loadChartData();
    }, [month]);

    return (
        <div className="bar-chart">
            <h3>Bar Chart</h3>
            <ul>
                {Object.entries(chartData).map(([range, count]) => (
                    <li key={range}>{range}: {count}</li>
                ))}
            </ul>
        </div>
    );
};

export default BarChart;
