import React from 'react';
import './Dropdown.css';

const Dropdown = ({ options, selected, onChange }) => {
    return (
        <div className="dropdown-container">
            <select
                className="dropdown"
                value={selected}
                onChange={(e) => onChange(e.target.value)}
            >
                {options.map(({ label, value }) => (
                    <option key={value} value={value}>
                        {label}
                    </option>
                ))}
            </select>
        </div>
    );
};

export default Dropdown;
