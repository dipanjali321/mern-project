import React, { useEffect, useState } from 'react';
import './TransactionTable.css'; // CSS for styling
import { fetchTransactions } from '../../services/api'; // Ensure API service is correctly implemented

const TransactionTable = () => {
    const [transactions, setTransactions] = useState([]);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    // Function to load transactions
    const loadTransactions = async () => {
        setLoading(true);
        setError(null);

        try {
            const response = await fetchTransactions(page, search); // Fetch data from API
            setTransactions(response.data);
            setTotalPages(response.totalPages || 1);
        } catch (err) {
            console.error('Error loading transactions:', err);
            setError('Failed to load transactions. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    // Fetch data whenever `page` or `search` changes
    useEffect(() => {
        loadTransactions();
    }, [page, search]);

    // Handle search input change
    const handleSearchChange = (e) => {
        setSearch(e.target.value);
        setPage(1); // Reset to first page when searching
    };

    // Render transactions or a fallback message if empty
    const renderTransactions = () => {
        if (transactions.length === 0) {
            return (
                <tr>
                    <td colSpan="4" className="no-data">
                        No transactions found.
                    </td>
                </tr>
            );
        }

        return transactions.map((transaction) => (
            <tr key={transaction._id}>
                <td>{transaction.title}</td>
                <td>{transaction.description}</td>
                <td>${transaction.price.toFixed(2)}</td>
                <td>{new Date(transaction.dateOfSale).toLocaleDateString()}</td>
            </tr>
        ));
    };

    return (
        <div className="transaction-table">
            {/* Search Input */}
            <input
                type="text"
                placeholder="Search transactions..."
                value={search}
                onChange={handleSearchChange}
                className="search-input"
            />

            {/* Loading or Error States */}
            {loading ? (
                <p>Loading transactions...</p>
            ) : error ? (
                <p className="error-message">{error}</p>
            ) : (
                <>
                    {/* Transactions Table */}
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>{renderTransactions()}</tbody>
                    </table>

                    {/* Pagination Controls */}
                    {totalPages > 1 && (
                        <div className="pagination">
                            <button
                                onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
                                disabled={page === 1}
                            >
                                Previous
                            </button>
                            <span>
                                Page {page} of {totalPages}
                            </span>
                            <button
                                onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
                                disabled={page === totalPages}
                            >
                                Next
                            </button>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default TransactionTable;
