import React, { useEffect, useState } from 'react';
import './PieChart.css';
import { fetchPieChartData } from '../../services/api';

const PieChart = ({ month }) => {
    const [chartData, setChartData] = useState({});

    useEffect(() => {
        const loadChartData = async () => {
            const data = await fetchPieChartData(month);
            setChartData(data);
        };
        loadChartData();
    }, [month]);

    return (
        <div className="pie-chart">
            <h3>Pie Chart</h3>
            <ul>
                {Object.entries(chartData).map(([category, count]) => (
                    <li key={category}>{category}: {count}</li>
                ))}
            </ul>
        </div>
    );
};

export default PieChart;
