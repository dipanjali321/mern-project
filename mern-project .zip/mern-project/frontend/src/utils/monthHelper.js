export const getCurrentMonth = () => {
    const now = new Date();
    return now.toLocaleString('default', { month: 'long' });
};

export const getMonthIndex = (month) => {
    return new Date(Date.parse(`${month} 1, 2000`)).getMonth();
};
