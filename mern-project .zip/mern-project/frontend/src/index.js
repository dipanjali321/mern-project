import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/index.css'; // Ensure your global styles are imported

// Find the root element in the DOM
const rootElement = document.getElementById('root');

// Check if the root element exists
if (rootElement) {
  // Create the React root using ReactDOM.createRoot
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} else {
  // Log an error if the root element is missing
  console.error("Root container not found in the DOM.");
}
