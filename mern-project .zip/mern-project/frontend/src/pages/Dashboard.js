import React, { useState } from 'react';
import TransactionTable from '../components/TransactionTable/TransactionTable';
import StatisticsBox from '../components/StatisticsBox/StatisticsBox';
import BarChart from '../components/BarChart/Barchart';
import PieChart from '../components/PieChart/PieChart';
import Dropdown from '../components/Dropdown/Dropdown';
import './Dashboard.css';

const Dashboard = () => {
    const [selectedMonth, setSelectedMonth] = useState('March');

    // List of months to be used in the dropdown
    const months = [
        'January', 'February', 'March', 'April', 'May',
        'June', 'July', 'August', 'September', 'October',
        'November', 'December',
    ];

    // Handle month change from the dropdown
    const handleMonthChange = (month) => {
        setSelectedMonth(month);
    };

    return (
        <div className="dashboard">
            <h1>Dashboard</h1>

            {/* Dropdown for selecting month */}
            <Dropdown
                options={months}
                selected={selectedMonth}
                onChange={handleMonthChange}
            />

            {/* StatisticsBox to show statistics for the selected month */}
            <StatisticsBox month={selectedMonth} />

            {/* TransactionTable to display transactions for the selected month */}
            <TransactionTable />

            {/* BarChart and PieChart to display charts for the selected month */}
            <BarChart month={selectedMonth} />
            <PieChart month={selectedMonth} />
        </div>
    );
};

export default Dashboard;
