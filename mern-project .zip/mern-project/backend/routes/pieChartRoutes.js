const express = require('express');
const router = express.Router();
const pieChartController = require('../controllers/pieChartController');

// Route to get data for the pie chart (e.g., transaction types distribution)
router.get('/', async (req, res) => {
    try {
        const pieChartData = await pieChartController.getPieChartData(req.query.month);
        res.json(pieChartData); // Send the pie chart data to the frontend
    } catch (error) {
        res.status(500).json({ message: 'Error fetching pie chart data' });
    }
});

module.exports = router;
