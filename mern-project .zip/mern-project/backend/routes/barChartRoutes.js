const express = require('express');
const router = express.Router();
const barChartController = require('../controllers/barChartController');

// Route to get data for the bar chart (e.g., transactions per month)
router.get('/', async (req, res) => {
    try {
        const barChartData = await barChartController.getBarChartData(req.query.month);
        res.json(barChartData); // Send the bar chart data to the frontend
    } catch (error) {
        res.status(500).json({ message: 'Error fetching bar chart data' });
    }
});

module.exports = router;
