const express = require('express');
const router = express.Router();
const statisticsController = require('../controllers/statisticsController');

// Route to get statistics data based on the selected month
router.get('/', async (req, res) => {
    try {
        const statistics = await statisticsController.getStatistics(req.query.month);
        res.json(statistics); // Send the statistics data to the frontend
    } catch (error) {
        res.status(500).json({ message: 'Error fetching statistics' });
    }
});

module.exports = router;
