const express = require('express');
const router = express.Router();
const combinedDataController = require('../controllers/combinedDataController');

// Route to get combined data for statistics, bar chart, and pie chart
router.get('/', combinedDataController.getCombinedData);

module.exports = router;
