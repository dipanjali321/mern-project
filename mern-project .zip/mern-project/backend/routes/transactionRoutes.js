const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactionController');

// Route to get all transactions (or optionally filtered by month)
router.get('/', async (req, res) => {
    try {
        const transactions = await transactionController.getAllTransactions(req.query.month);
        res.json(transactions); // Send the transaction data to the frontend
    } catch (error) {
        res.status(500).json({ message: 'Error fetching transactions' });
    }
});

module.exports = router;
