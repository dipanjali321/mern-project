module.exports = {
    API_URL: 'https://s3.amazonaws.com/roxiler.com/product_transaction.json',
    PAGE_SIZE: 10,
};
