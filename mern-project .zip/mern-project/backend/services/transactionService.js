const Transaction = require('../models/Transaction');
const fs = require('fs');
const path = require('path');

/**
 * Fetch transactions from data.json and save them to the database.
 */
exports.fetchAndSaveTransactions = async () => {
    try {
        const dataPath = path.join(__dirname, '../data/data.json');
        const transactions = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));

        if (transactions && transactions.length) {
            await Transaction.insertMany(transactions);
            console.log('Transactions successfully saved to the database.');
        } else {
            console.warn('No transactions found in the data file.');
        }
    } catch (error) {
        console.error('Error fetching or saving transactions:', error);
        throw new Error('Failed to fetch or save transactions.');
    }
};

/**
 * Fetch all transactions from the database.
 */
exports.getAllTransactions = async () => {
    try {
        return await Transaction.find();
    } catch (error) {
        console.error('Error fetching transactions from the database:', error);
        throw new Error('Unable to retrieve transactions.');
    }
};
