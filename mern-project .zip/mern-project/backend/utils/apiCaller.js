const axios = require('axios');
const { API_URL } = require('../config/constants');

// Helper to call third-party API
exports.fetchData = async () => {
    try {
        const response = await axios.get(API_URL);
        return response.data;
    } catch (error) {
        console.error('Error fetching API data:', error);
        throw error;
    }
};
