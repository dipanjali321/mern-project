// Helper function to parse and filter transactions by month
exports.parseMonth = (date, month) => {
    const transactionDate = new Date(date);
    const targetMonth = new Date(month).getMonth(); // Month index (0-11)
    return transactionDate.getMonth() === targetMonth;
};
