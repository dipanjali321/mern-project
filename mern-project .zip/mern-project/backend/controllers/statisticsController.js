const { Transaction } = require('../models/Transaction');

// Controller function to get statistics for a specific month
const getStatisticsForMonth = async (req, res) => {
    try {
        // Get month from query params (e.g., 'March')
        let { month } = req.query;

        if (!month) {
            console.log('Month not provided');
            return res.status(400).json({ message: 'Month is required' });
        }

        // Sanitize the month parameter: remove any extra spaces or newline characters
        month = month.trim().replace(/[\r\n]+/g, '').toString();

        console.log('Sanitized month:', month);

        // List of valid month names
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        // Check if the provided month is valid
        const monthIndex = monthNames.indexOf(month);
        if (monthIndex === -1) {
            console.log('Invalid month name:', month);
            return res.status(400).json({ message: 'Invalid month name provided. Please use a valid month name.' });
        }

        // Convert month to start and end date (using the year 2021 for example)
        const startOfMonth = new Date(2021, monthIndex, 1);
        const endOfMonth = new Date(2021, monthIndex + 1, 0);

        console.log('Start of month:', startOfMonth);
        console.log('End of month:', endOfMonth);

        // Query database to get transactions for the specific month
        const transactions = await Transaction.find({
            dateOfSale: { $gte: startOfMonth, $lt: endOfMonth }
        });

        console.log('Transactions found:', transactions);

        // If no transactions are found, return zero values
        if (transactions.length === 0) {
            console.log('No transactions for this month');
            return res.json({
                totalAmount: 0,
                averageAmount: null,
                count: 0,
            });
        }

        // Aggregate data based on the month
        const statistics = await Transaction.aggregate([
            {
                $match: {
                    dateOfSale: { $gte: startOfMonth, $lt: endOfMonth },
                },
            },
            {
                $group: {
                    _id: null,
                    totalAmount: { $sum: '$price' },
                    averageAmount: { $avg: '$price' },
                    count: { $sum: 1 },
                },
            },
        ]);

        console.log('Statistics aggregated:', statistics);

        // If statistics are available, return them; otherwise, return zero values
        if (statistics.length > 0) {
            return res.json({
                totalAmount: statistics[0].totalAmount,
                averageAmount: statistics[0].averageAmount,
                count: statistics[0].count,
            });
        } else {
            console.log('No statistics available');
            return res.json({
                totalAmount: 0,
                averageAmount: null,
                count: 0,
            });
        }
    } catch (error) {
        // Log detailed error for debugging
        console.error('Error fetching statistics:', error.message || error);
        res.status(500).send({ message: 'Server Error. Please try again later.' });
    }
};

module.exports = { getStatisticsForMonth };
