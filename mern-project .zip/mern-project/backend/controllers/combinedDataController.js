const statisticsController = require('./statisticsController');
const barChartController = require('./barChartController');
const pieChartController = require('./pieChartController');

exports.getCombinedData = async (req, res) => {
    try {
        const { month } = req.query;

        const [statistics, barChartData, pieChartData] = await Promise.all([
            statisticsController.getStatistics(month),
            barChartController.getBarChartData(month),
            pieChartController.getPieChartData(month),
        ]);

        res.json({ statistics, barChartData, pieChartData });
    } catch (error) {
        console.error('Error in getCombinedData:', error.message);
        res.status(500).json({ message: 'Error fetching combined data' });
    }
};
