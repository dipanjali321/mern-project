const Transaction = require('../models/Transaction');
const PAGE_SIZE = 10; // Default page size

// Get all transactions with search and pagination
exports.getTransactions = async (req, res) => {
    try {
        // Extract query parameters
        const { page = 1, limit = PAGE_SIZE, search = '' } = req.query;

        // Convert `page` and `limit` to integers
        const pageNum = parseInt(page, 10) || 1;
        const pageLimit = parseInt(limit, 10) || PAGE_SIZE;

        // Construct a regex-based search query
        const regex = new RegExp(search, 'i'); // Case-insensitive search
        const query = {
            $or: [
                { title: { $regex: regex } },
                { description: { $regex: regex } },
                { price: { $regex: regex } }, // Assumes `price` is stored as a string; adjust if numeric
            ],
        };

        // Fetch paginated transactions
        const transactions = await Transaction.find(query)
            .skip((pageNum - 1) * pageLimit)
            .limit(pageLimit);

        // Get total count for pagination
        const totalTransactions = await Transaction.countDocuments(query);

        // Construct response
        res.json({
            data: transactions,
            totalTransactions,
            totalPages: Math.ceil(totalTransactions / pageLimit),
            currentPage: pageNum,
        });
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({ message: 'Error fetching transactions' });
    }
};
