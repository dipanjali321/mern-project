const Transaction = require('../models/Transaction');

// Controller method to get data for the bar chart
exports.getBarChartData = async (month) => {
    try {
        // Fetch transactions for the specified month (or all if no month is provided)
        const query = month ? { month: month } : {};
        const transactions = await Transaction.find(query);

        // Aggregate the transactions by month
        const monthlyData = transactions.reduce((acc, transaction) => {
            const month = transaction.date.split('-')[1]; // Extract month from date
            if (!acc[month]) {
                acc[month] = 0;
            }
            acc[month] += transaction.amount;
            return acc;
        }, {});

        // Convert the aggregated data into an array of { month, totalAmount }
        const barChartData = Object.keys(monthlyData).map((month) => ({
            month,
            totalAmount: monthlyData[month],
        }));

        return barChartData; // Return the processed data for the bar chart
    } catch (error) {
        console.error('Error fetching bar chart data:', error);
        throw new Error('Error fetching bar chart data');
    }
};
