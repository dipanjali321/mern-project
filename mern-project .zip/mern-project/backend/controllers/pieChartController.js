const Transaction = require('../models/Transaction');

// Controller method to get data for the pie chart
exports.getPieChartData = async (month) => {
    try {
        // Fetch transactions for the specified month (or all if no month is provided)
        const query = month ? { month: month } : {};
        const transactions = await Transaction.find(query);

        // Aggregate the transactions by category (assuming each transaction has a category field)
        const categoryData = transactions.reduce((acc, transaction) => {
            const category = transaction.category; // Assuming 'category' is a field in the transaction
            if (!acc[category]) {
                acc[category] = 0;
            }
            acc[category] += transaction.amount;
            return acc;
        }, {});

        // Convert the aggregated data into an array of { category, totalAmount }
        const pieChartData = Object.keys(categoryData).map((category) => ({
            category,
            totalAmount: categoryData[category],
        }));

        return pieChartData; // Return the processed data for the pie chart
    } catch (error) {
        console.error('Error fetching pie chart data:', error);
        throw new Error('Error fetching pie chart data');
    }
};
