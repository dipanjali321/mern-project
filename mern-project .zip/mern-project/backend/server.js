const app = require('./app');
const connectDB = require('./config/db');
const transactionService = require('./services/transactionService');
const Transaction = require('./models/Transaction');

// Connect to the database
connectDB();

// Seed the database if it's empty
const seedDatabase = async () => {
    try {
        const existingData = await Transaction.find();
        if (existingData.length === 0) {
            await transactionService.fetchAndSaveTransactions();
            console.log('Database seeded with initial data.');
        } else {
            console.log('Database already contains data.');
        }
    } catch (error) {
        console.error('Error during database seeding:', error);
    }
};

// Call the seeding function
seedDatabase();

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
